//
//  ViewController.m
//  Test
//
//  Created by BruceYao on 16/7/18.
//  Copyright © 2016年 BruceYao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self calueWaterAndFire];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)calueWaterAndFire {
//    1、有甲、乙两个桶，甲桶中有酒精12千克，水18千克；乙桶中有酒精9千克，水3千克。现从两桶中各取多少千克，才能使配成的混合液体里含有酒精和水各7千克？
//    甲桶x1：酒  x2：水
    
    for (int x1 = 0; x1 < 10; x1++) {
        for (int x2 = 0; x2 < 10; x2++) {
            for (int x3 = 0; x3 < 10; x3++) {
                for (int x4 = 0; x4 < 10 ; x4++) {
                   
                    if ((x1 == x2) || (x1 == x3) || (x1 == x4) || (x2 == x3) || (x2 == x4) || (x3 == x4)) {
                        break;
                    }
                    else {
                        if (x1 + x2 + x3 + x4 == 6 && (x1 * 1000 + x2 * 100 + x3 * 10 + x4) % 11 == 0) {
                            NSLog(@"%d - %d - %d - %d", x1, x2, x3, x4);
                        }
                        
                    }
//                    if (x1 + x2 + x3 + x4 == 6 && (x1 + x2 + x3 + x4) % 11 == 0) {
//                        NSLog(@"%d - %d - %d - %d", x1, x2, x3, x4);
//                    }
                    
                }
            }
        }
    }
    
    NSLog(@"ddd");
//    乙桶y1：酒  y2：水
    CGFloat y1 = 0;
    CGFloat y2 = 0;
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
